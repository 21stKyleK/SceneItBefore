using UnityEngine;
using UnityEngine.UI;

public class SearchIconToggle : MonoBehaviour
{
    public InputField searchInputField; 
    public GameObject searchIcon;

    void Start()
    {
        searchInputField.onValueChanged.AddListener(ToggleSearchIcon);
    }

    void ToggleSearchIcon(string text)
    {
        searchIcon.SetActive(string.IsNullOrEmpty(text));
    }
}
