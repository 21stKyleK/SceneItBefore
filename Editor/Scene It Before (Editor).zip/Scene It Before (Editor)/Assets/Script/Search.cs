using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

public class Search : MonoBehaviour
{
    public InputField searchInputField; 
    public Transform buttonContainer;    

    private List<GameObject> buttons = new List<GameObject>();

    void Start()
    {

        foreach (Transform child in buttonContainer)
        {
            buttons.Add(child.gameObject);
        }

        searchInputField.onValueChanged.AddListener(FilterButtons);
    }

    void FilterButtons(string query)
    {
        query = query.ToLower();

        foreach (GameObject button in buttons)
        {
            Text hiddenText = button.GetComponentInChildren<Text>(true); 

            if (hiddenText != null)
            {
                bool match = hiddenText.text.ToLower().Contains(query);
                button.SetActive(match);
            }
        }

       
        if (string.IsNullOrEmpty(query))
        {
            foreach (GameObject button in buttons)
            {
                button.SetActive(true);
            }
        }
    }
}