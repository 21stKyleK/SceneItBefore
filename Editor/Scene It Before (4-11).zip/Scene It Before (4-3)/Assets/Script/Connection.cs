using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using NativeWebSocket;

public class Connection : MonoBehaviour
{
    WebSocket websocket;
    public GameObject propPreFab;
    public GameObject propPreFab1;

    // Start is called before the first frame update
    async void Start()
    {
        websocket = new WebSocket("wss://www.sceneitbefore.org/ws");

        websocket.OnOpen += () =>
        {
            Debug.Log("Connection open!");
            websocket.SendText("Hello/Unity");
            websocket.SendText("Go/Stage1");
        };

        websocket.OnError += (e) =>
        {
            Debug.Log("Error! " + e);
        };

        websocket.OnClose += (e) =>
        {
            Debug.Log("Connection closed!");
        };

        websocket.OnMessage += (bytes) =>
        {
            //Debug.Log("OnMessage!");
            //Debug.Log(bytes);

            // getting the message as a string
            var message = System.Text.Encoding.UTF8.GetString(bytes);
            Debug.Log("OnMessage! " + message);

            string[] parts = message.Split('/');
            string[] nameParts = parts[1].Split('|');

            if ("Create".Equals(parts[0])){
                
                GameObject prefab = "PropPreFab".Equals(nameParts[0]) ? propPreFab : propPreFab1;
                Vector3 pos = new Vector3(int.Parse(parts[2]), int.Parse(parts[3]), int.Parse(parts[4]));
                GameObject newThing = Instantiate(prefab, pos, new Quaternion(int.Parse(parts[5]), int.Parse(parts[6]), int.Parse(parts[7]), 0));
                newThing.transform.localScale = new Vector3(int.Parse(parts[8]), int.Parse(parts[9]), int.Parse(parts[10]));
                newThing.name = parts[1];

                newThing.GetComponent<MeshLoader>().LoadMeshFromPath($"{Application.dataPath}/{nameParts[1]}.dat");
            }
            else if ("Move".Equals(parts[0])){
                foreach (GameObject g in GameObject.FindGameObjectsWithTag("Player"))
                {
                    if (g.name.Equals(parts[1]))
                    {
                        Vector3 pos = new Vector3(int.Parse(parts[2]), int.Parse(parts[3]), int.Parse(parts[4]));
                        g.transform.position = pos;
                    }
                }
            }
            else if ("Rotate".Equals(parts[0]))
            {
                foreach (GameObject g in GameObject.FindGameObjectsWithTag("Player"))
                {
                    if (g.name.Equals(parts[1]))
                    {
                        Quaternion rotate = new Quaternion(int.Parse(parts[2]), int.Parse(parts[3]), int.Parse(parts[4]), 0);
                        g.transform.rotation = rotate;
                    }
                }
            }
            else if ("Scale".Equals(parts[0]))
            {
                foreach (GameObject g in GameObject.FindGameObjectsWithTag("Player"))
                {
                    if (g.name.Equals(parts[1]))
                    {
                        Vector3 scale = new Vector3(int.Parse(parts[2]), int.Parse(parts[3]), int.Parse(parts[4]));
                        g.transform.localScale = scale;
                    }
                }
            }
        };

        // Keep sending messages at every 0.3s
        // InvokeRepeating("SendWebSocketMessage", 0.0f, 0.3f);

        // waiting for messages
        await websocket.Connect();
    }

    void Update()
    {
#if !UNITY_WEBGL || UNITY_EDITOR
        websocket.DispatchMessageQueue();
#endif
    }

    public async void SendWebSocketMessage(string msg)
    {
        if (websocket.State == WebSocketState.Open)
        {
            // Sending bytes
            // await websocket.Send(new byte[] { 10, 20, 30 });

            // Sending plain text
            await websocket.SendText(msg);
        }
    }

    private async void OnApplicationQuit()
    {
        await websocket.Close();
    }

}
