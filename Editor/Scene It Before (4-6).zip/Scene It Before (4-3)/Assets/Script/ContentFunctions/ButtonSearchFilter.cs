using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

public class ButtonSearchFilter : MonoBehaviour
{
    public InputField searchInputField; 
    public Transform buttonContainer;  

    private List<GameObject> buttons = new List<GameObject>();

    void Start()
    {
  
        foreach (Transform child in buttonContainer)
        {
            buttons.Add(child.gameObject);
        }

     
        searchInputField.onValueChanged.AddListener(FilterButtons);
    }

    void FilterButtons(string query)
    {
        query = query.ToLower();

        bool anyMatch = false;

        foreach (GameObject button in buttons)
        {
            Text hiddenText = button.GetComponentInChildren<Text>(true);

            if (hiddenText != null && hiddenText.text.ToLower().Contains(query))
            {
                button.SetActive(true);
                anyMatch = true;
            }
            else
            {
                button.SetActive(false);
            }
        }

      
        if (string.IsNullOrEmpty(query))
        {
            foreach (GameObject button in buttons)
            {
                button.SetActive(true);
            }
        }

        //just to get this out of the log
        if (anyMatch)
        {
            Debug.Log("A");
        }
    }
}