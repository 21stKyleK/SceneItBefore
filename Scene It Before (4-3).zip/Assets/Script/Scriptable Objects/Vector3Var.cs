using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Scriptable Variables/Vector3")]
public class Vector3Var : GenericNumVar<Vector3>
{
    //since there isn't much else to do with this script, will be blank.
    //see GenericNumVar for the code
}
